import React from 'react'
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
 
} from "react-router-dom";
import Home from './Home';
import Login from './Login';
import Createuser from './Createuser';
function AppRouter() {
  return (
    <div>
        <Router>
          <Routes>
          <Route path='/' element ={JSON.parse(sessionStorage.getItem("isLogin")) ?<Createuser/>: <Navigate to = "/login" />} />
          <Route path='/' element ={JSON.parse(sessionStorage.getItem("isCreate")) ?<Home/>: <Navigate to = "/login" />} />
            <Route path = '/login' element ={<Login/>}/>
            <Route path = '/Createuser' element = {<Createuser/>}/>
          </Routes>

        </Router>
    </div>
  )
}

export default AppRouter;