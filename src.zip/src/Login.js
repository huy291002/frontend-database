import React from 'react'
import './Login.css'
import { Layout } from 'antd';
import {useState} from 'react'
import { useNavigate } from 'react-router-dom';
const { Header, Content } = Layout;
function Login() {
    const[username, setusername] = useState("");
    const[passwords, setPassword] = useState("");
    const navigate = useNavigate();
    
    function login(e)
    {
        e.preventDefault();
        console.log("Username: ", username);
        console.log("Password: ", passwords);
        sessionStorage.setItem("isLogin", 'true');
       navigate('/');
          
        
    }
  return (
    <Layout style={{height: "100vh"}}>
    
    <Layout>
        <Header style = {{backgroundColor: "transparent", textAlign: "center", color: "black", fontWeight: "bold"}}>
        <div className="container bg-transparent">
            <div className = "position-fixed top-0 start-0">
                <img src="https://i.ibb.co/55dcLG1/logo.png" alt="logo" border="0" width="60px" height="56px"/>
            </div>
            <div className="row">
                <div class="col-12 display-5 ">Entertainment show</div>
            </div>
            </div>
        </Header>
    <Content>

   
    <div class= "container middle">
        <form onSubmit = {login} class="align-items-center p-3 mt-3" >
            <div class="text-center fs-6 ">
                <span class = "far fa-user" ></span>
                <input type="text" class = "sizeofbox" name = "username" id = "username" placeholder="Username"  onChange ={(e)=> {setusername(e.target.value);}} required/>
                
                        
                
            </div>
               
            <div class="text-center fs-6 mt-3 ">
            <label for="inputPassword2" class="visually-hidden">Password</label>
                <span class = "fas fa-key"></span>
                <input type="password" class ="sizeofbox" name = "password" id ="pwd" placeholder="Password" onChange={(e) => {setPassword(e.target.value);}} required/>
              
            </div>
           
            <div class=" text-center fs-6 mt-3">
                <button class="btn btn-primary " type="submit">Login</button>
            </div>
        </form>
        <div class = "text-center fs-6">
            <a href = "#">Forget password?</a>
        </div>
    </div>
    </Content>
    </Layout>
    </Layout>
  )
}

export default Login