import { Layout } from 'antd';
import React, { useEffect } from 'react';
import './Home.css';
import { useState } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css'
import Button from 'react-bootstrap/Button'
import Modal from 'react-bootstrap/Modal';
// import { Input } from 'antd';
const { Header, Content } = Layout;
   
function Home() {
    const[word1, setWord1] = useState("");
    const[words1, setWords1] = useState([]);
    const[word, setWord] = useState("");
    const[words, setWords] = useState([]);
    const [selectedDate, setSelectedDate] = useState(null);
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const[view, setView] = useState(false);
    const cancelView = () => setView(false);
    const handleView = () => setView(true);
    function search(e)
    {
        e.preventDefault();
        console.log("Name: ", word);
        setWords((prev) => [...prev, word]);

    }
   
    useEffect(()=> {
        if (words.length > 0)
        {
            console.log("Use effect:")
            console.log("Word: ", words)
        }
    }, [words])
    useEffect(()=> {
        if (words1.length > 0)
        {
            console.log("Use effect:")
            console.log("Word: ", words1)
        }
    }, [words1])
   return (

    <Layout style={{height: "100vh"}}>
    
    <Layout>
        <Header style = {{backgroundColor: "transparent", textAlign: "center", color: "black", fontWeight: "bold"}}>
        <div className="container bg-transparent">
            <div className = "position-fixed top-0 start-0">
                <img src="https://i.ibb.co/55dcLG1/logo.png" alt="logo" border="0" width="60px" height="56px"/>
            </div>
            <div className="row">
                <div class="col-12 display-5 ">Entertainment show</div>
            </div>
            </div>
        </Header>
        <Content>
            <div className="container text center">
                <div className = "row" class = "text-align-right" style ={{textAlign: 'right'}}>         
                    <>
                    <Button className ="col-1 "  variant="primary" onClick={handleShow}>
                        Add 
                    </Button>

                    <Modal size = "lg" aria-labelledby= "contained-modal-title-vcenter" centered 
                    show={show} onHide={handleClose}>
                        <Modal.Header closeButton>
                        <Modal.Title>Information's trainee needed</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <form class = "row g-3">
                                <div class = "col-12">
                                    <label for = "inputname1" class = "form-label">SSN</label><br></br>
                                    <input type="text" class = "sizeofbox"  rows="4"></input>
                                </div>
                                <br></br>
                                <div class = "col-12">
                                    <label for = "inputname1" class = "form-label">FName</label><br></br>
                                    <input type="text" class = "sizeofbox"  ></input>
                                </div>
                                <div class = "col-12">
                                    <label for = "inputname1" class = "form-label">LName</label><br></br>
                                    <input type="text" class = "sizeofbox"  ></input>
                                </div>
                                <div class = "col-12">
                                    <label for = "inputname1" class = "form-label">Address</label><br></br>
                                    <input type="text" class = "sizeofbox"  ></input>
                                </div>
                                <div class = "col-6">
                                    <div className='App '>
                                    <label for = "inputname1" class = "form-label">Date of birth</label><br></br>
                                        <DatePicker selected={selectedDate} 
                                                    onChange={date => setSelectedDate(date)} 
                                                    dateFormat = 'dd/MM/yyyy'
                                                    />    
                                    </div>
                                </div>
                                <div class = "col-6">
                                    <label for="formFile" class="form-label">Photo of trainee</label>
                                    <input class="form-control" type="file" id="formFile"/>
                                </div>
                                
                            </form>
                        </Modal.Body>
                        <Modal.Footer>
                        <Button variant="secondary" onClick={handleClose}>
                            Cancel
                        </Button>
                        <Button variant="primary" onClick={handleClose}>
                            Add
                        </Button>
                        </Modal.Footer>
                    </Modal> 
                    </>
                </div>
            </div>
        
    <div className ="container text-center">
   
        <div className="container text-center">    
            <div className="row mt-2">
                <div className="col-4 border-right" >
                    <div className="mb-3">
                        <form onSubmit={search}>
                            <label for="exampleFormControlTextarea1" class="form-label">Enter trainee's name</label>
                            <input className="form-control" id="exampleFormControlTextarea1" onChange={(e)=>{
                            setWord(e.target.value);
                            }}
                            rows="3"></input>
                            <button type="submit" class ="btn btn-primary mb-3">Search</button>
                           
                        </form>
                    </div>  
                </div>
              
                <div className="col-8">
                    
                    <div class="table table-bordered">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th class ="col-6 table-align-middle" style={{width: "50%"}} >Trainee's full name</th>
                                    <th class ="col-2 table-align-middle" style={{width: "30%"}}  >SSN </th>
                                    <th class ="col-4 table-align-middle" style={{width: "20%"}} > </th>
                                </tr>
                            </thead>
                            <tbody>
                            {
                                words.map((singleWords) => {
                                    return (
                                        <tr>
                                            <td  class="col-6 border-right-table " style={{width: "50%"}}> {singleWords}</td>
                                            <td class="col-2 border-right-table " style ={{width: "30%"}}> 
                                            </td>

                                            <td class="col-4 " style ={{width: "20%"}}>
                                                
                                                <Button className ="col-12 "  variant="primary" onClick={handleView}>
                                                    View info
                                                </Button>

                                                <Modal size = "lg" aria-labelledby= "contained-modal-title-vcenter" centered 
                                                show={view} onHide={cancelView}>
                                                    <Modal.Header closeButton>
                                                    <Modal.Title>Information's trainee </Modal.Title>
                                                    </Modal.Header>
                                                    <Modal.Body>
                                                        <form class = "row g-3">
                                                            <div class = "col-12">
                                                                <label  class = "form-label">Full Name:</label><br></br>
                                                               
                                                            </div>
                                                            <br></br>
                                                            <div class = "col-12">
                                                                <label  class = "form-label">SSN:</label><br></br>
                                                               
                                                            </div>
                                                            <div class = "col-12">
                                                                <label  class = "form-label">Address:</label><br></br>
                                                               
                                                            </div>
                                                            <div class = "col-12">
                                                                <label  class = "form-label">Number of seasons participating:</label><br></br>
                                                               
                                                            </div>
                                                            <div class = "col-12">
                                                            <label  class = "form-label">Achievement:</label><br></br>
                                                            </div>
                                                            <div class = "col-12">
                                                                <label  class="form-label">Photo of trainee:</label>
                                                            </div>
                                                            
                                                        </form>
                                                    </Modal.Body>
                                                    <Modal.Footer>
                                                        <Button variant="primary" onClick={cancelView}>
                                                            Close
                                                        </Button>
                                                        
                                                    </Modal.Footer>
                                                </Modal> 
                                               
                                            </td>
                                        </tr>
                                    )
                                })

                            }
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
        </div>
    </div> 
    
          

        
         
                 
        </Content>
        
    </Layout>
    </Layout>

   )
}
export default Home;