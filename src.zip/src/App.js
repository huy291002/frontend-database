
import "./App.css";
import AppRouter from "./Router";
export default function App() {
  return (
    <div className="home">
      <AppRouter/>
    </div>
    
  );
}
