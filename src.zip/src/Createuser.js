import React from 'react'
import { Layout } from 'antd';
import  { useEffect } from 'react';
import { useState } from 'react';
import DropdownButton from 'react-bootstrap/DropdownButton';
import Dropdown from 'react-bootstrap/Dropdown'
import 'react-dropdown/style.css';
import Select from "react-select";
import { useNavigate } from 'react-router-dom';
const { Header, Content } = Layout;
function Createuser() { 
    const [roles,setRoles] = useState([]);
    const[value,setValue]= useState('');
    const[username, setusername] = useState("");
    const[passwords, setPassword] = useState("");
    const navigate = useNavigate();
 
    function createuser(e)
    {
        e.preventDefault();
        console.log("Username: ", username);
        console.log("Password: ", passwords);
        sessionStorage.setItem("isCreate", 'true');
       
            navigate('/');
        
    }
    const [selectedOptions, setSelectedOptions] = useState();
    const optionList = [
        { value: "SELECT", label: "SELECT" },
        { value: "INSERT", label: "INSERT" },
        { value: "UPDATE", label: "UPDATE" },
        { value: "DELETE", label: "DELETE" }
    ];
    function handleSelect(data) {
        setSelectedOptions(data);
        
    }
    useEffect(() => {
        console.log(selectedOptions);
    }, [selectedOptions]);
  return (
    <Layout style={{height: "100vh"}}>
    <Layout>
        <Header style = {{backgroundColor: "transparent", textAlign: "center", color: "black", fontWeight: "bold"}}>
        <div className="container bg-transparent">
            <div className = "position-fixed top-0 start-0">
                <img src="https://i.ibb.co/55dcLG1/logo.png" alt="logo" border="0" width="60px" height="56px"/>
            </div>
            <div className="row">
                <div class="col-12 display-5 ">Entertainment show</div>
            </div>
            </div>
        </Header>
    <Content>

   
    <div className = "padd" class= "container middle  pt-5 ">
        <div class = "container middle">
            <div style ={{textAlign: "center", color: "black", fontSize: 25}}>Create user</div>
        </div>
        <form onSubmit = {createuser} class="align-items-center p-3 mt-3" >
            <div class="text-center fs-6 ">
                <span class = "far fa-user" ></span>
                <input type="text" class = "sizeofbox" name = "username" id = "username" placeholder="Username"  onChange ={(e)=> {setusername(e.target.value);}} required/>
                
                        
                
            </div>
               
            <div class="text-center fs-6 mt-3 ">
            <label for="inputPassword2" class="visually-hidden">Password</label>
                <span class = "fas fa-key"></span>
                <input type="password" class ="sizeofbox" name = "password" id ="pwd" placeholder="Password" onChange={(e) => {setPassword(e.target.value);}} required/>
              
            </div>
            <br></br>
            <div className="App container " class="text-center">
            <Select
                options={optionList}
                placeholder="Select color"
                value={selectedOptions}
                onChange={handleSelect}
                isSearchable={true}
                isMulti
            />
    
    </div>
            <div class=" text-center fs-6 mt-3">
                <button class="btn btn-primary " type="submit">Create</button>
            </div>
        </form>
        
    </div>
    </Content>
    </Layout>
    </Layout>
  )
}

export default Createuser